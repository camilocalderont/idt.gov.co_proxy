<?php

namespace Drupal\slick;

use Drupal\blazy\BlazyFormatterInterface;

/**
 * Defines re-usable services and functions for slick field plugins.
 */
interface SlickFormatterInterface extends BlazyFormatterInterface {}
