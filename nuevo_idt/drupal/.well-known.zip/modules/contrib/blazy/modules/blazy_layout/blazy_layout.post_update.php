<?php

/**
 * @file
 * Post update hooks for Blazy layout.
 */

/**
 * Renamed classes.
 */
function blazy_layout_post_update_renamed_classes() {
  // DO nothing to clear cache.
}
