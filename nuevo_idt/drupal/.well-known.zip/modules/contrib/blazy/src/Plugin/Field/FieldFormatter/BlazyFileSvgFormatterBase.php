<?php

namespace Drupal\blazy\Plugin\Field\FieldFormatter;

/**
 * Base class for blazy/slick image, and file ER formatters with SVG.
 *
 * @todo fill out the contents after sub-modules extending this.
 */
abstract class BlazyFileSvgFormatterBase extends BlazyFileFormatterBase {

}
