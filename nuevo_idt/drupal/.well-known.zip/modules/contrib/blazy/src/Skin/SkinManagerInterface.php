<?php

namespace Drupal\blazy\Skin;

/**
 * Provides an interface defining skins, and asset managements.
 */
interface SkinManagerInterface extends SkinManagerBaseInterface {}
