<?php

namespace Drupal\blazy\Views;

/**
 * Provides base views style plugin interface.
 */
interface BlazyStyleBaseInterface extends BlazyStyleVanillaInterface {}
