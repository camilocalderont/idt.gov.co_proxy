<?php

namespace Drupal\blazy\Views;

/**
 * Provides common views style plugin interface.
 */
interface BlazyStylePluginInterface extends BlazyStyleBaseInterface {}
