
## Slick Development Module

Provides options to ease up Slick development.
